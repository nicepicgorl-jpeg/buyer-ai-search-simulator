---
name: "buyer-ai-search-simulator"
description: "Simulate and research how buyers discover and evaluate a brand across Google and AI assistants: query libraries, AI prompts, keyword demand validation, competitor and buyer-language research, AI visibility testing, and evidence-backed SEO/GEO priorities. Use whenever the user wants buyer search behaviour, AI-search or GEO visibility analysis, query or prompt libraries, or evidence-backed content opportunities for a brand, even if they do not name the skill."
---

# Buyer AI Search Simulator

## Mission

Simulate realistic buyer search behavior for a brand in a specified market. Discover what prospective customers might type into Google and ask AI assistants, then separate those hypotheses from measured search demand and observed brand visibility.

This skill supports SEO, generative engine optimization (GEO), content strategy, market research, and repeatable AI-search visibility testing.

**Core rule:** Query generation, demand validation, visibility testing, and performance analysis are separate activities. Never present one as evidence of another. Every meaningful finding carries an evidence label (SUPPLIED, OBSERVED, VALIDATED, INFERRED, SIMULATED, UNKNOWN, NOT TESTED) so a reader can tell what was measured from what was generated. Definitions are in `references/research-validation.md`.

## Inputs

### Required
1. **Brand name**
2. **Official website URL**
3. **Target country or market**

### Optional
- Target cities, regions, or postcodes
- Product/service categories to prioritize
- Target audience or customer segment
- Known competitors
- Research objective: SEO, GEO, content strategy, competitor research, or combined
- Depth: `Quick`, `Standard`, or `Comprehensive`
- Output preference: readable report, spreadsheet-ready tables, or both
- Exclusions, constraints, or priority questions

Research mode comes first: the user chooses Simulation, Research or Full Intelligence Mode (see Startup message) before any brand details are collected, because the mode decides which workflow, tools and deliverables apply. If the user has already supplied the required inputs, do not ask for them again. If the three required inputs are provided and optional fields are absent, use sensible defaults and proceed once the mode is confirmed. Ask a concise question only when missing information materially blocks accurate research.

### Default depth
- **Quick:** about 40 Google queries, 30 AI prompts, 3 simulated conversations, 10 priority tests.
- **Standard:** about 100 Google queries, 80 AI prompts, 5 simulated conversations, 20 priority tests.
- **Comprehensive:** about 200 Google queries, 150 AI prompts, 8 simulated conversations, 30 priority tests.

These are target counts, not an excuse to pad the dataset. If meaningful unique queries are exhausted, explain the shortfall rather than inventing variants. If output limits prevent delivery in one response, deliver clearly numbered batches and state what remains.

## Operating modes

Three modes exist, and the user selects one at the start (see Startup message). Run the mode they chose, state it in the report, and never claim more than was done. If the chosen mode needs tools that are not connected, say so before starting and let the user decide whether to proceed with the limitations disclosed or switch mode; never silently upgrade or downgrade. Full rules for each mode are in `references/research-validation.md` (read it before starting Research or Full Intelligence Mode).

1. **Simulation Mode** — the user selected it, or external research tools are unavailable and the user agrees to proceed. Generate personas, jobs-to-be-done, queries, prompts, journeys and multi-turn conversations as hypotheses. Make no claims about search demand, competitor findings, rankings, citations or AI visibility. Label every generated insight as a hypothesis or simulated finding.
2. **Research Mode** — the user selected it and web search and/or keyword tools are available. Validate the generated research against real evidence: keyword metrics, SERPs, autocomplete and People Also Ask, competitor pages, reviews and forums, Google Trends, local intent, and content gaps. Record the tool, metric, geography, date and limitations for every figure. Mark unavailable metrics as unavailable rather than estimating them.
3. **Full Intelligence Mode** — Research Mode plus persona and journey simulation, multi-turn testing, actual AI-assistant visibility tests where accessible, brand and competitor mention tracking, citation and source analysis, accuracy analysis, and SEO/GEO recommendations. If live AI testing is not possible, keep the prompts as a testing plan marked NOT TESTED.

Simulation Mode uses no external tools. Before Research or Full Intelligence Mode, run capability discovery as described in **Capability-first research** below, and record what is unavailable. Fallbacks: web search only means qualitative research with quantitative metrics marked unavailable; keyword tools only means demand validation without competitor or buyer-discussion claims; neither means the selected mode cannot be delivered as described: tell the user and offer Simulation Mode instead.

Do not claim to have queried ChatGPT, Perplexity, Gemini, Google, or any other platform unless you actually did so with an available tool or the user supplied the results.

## Capability-first research

This skill is provider-independent. People run it with different stacks (Ahrefs, Semrush, DataForSEO, SEO Vendor, Tavily, Google Search Console, plain web search, a browser, uploaded exports), and the skill cannot know in advance which. So plan and describe every research step as a **capability** ("retrieve keyword search volume"), never as a named vendor ("use Ahrefs"), and let whatever the environment exposes fulfil it. A vendor name that appears in a reference file or in the user's request is an example of a provider, not a requirement.

### Capability matrix

| Capability | Needed for | If unavailable |
|---|---|---|
| Web search | Market, brand and competitor research | Rely on the official site and user-supplied material; mark external claims UNKNOWN |
| Page extraction | Inspecting actual source content, not snippets | Do not make claims about page content; mark NOT TESTED |
| Keyword metrics (volume, difficulty, CPC, trend) | Quantitative demand validation | Mark demand **unvalidated** and metrics unavailable; never estimate |
| SERP data | Search-result and competitor-visibility analysis | Skip SERP claims; use qualitative web search only |
| Trend data | Seasonality and interest patterns | Omit seasonality claims |
| Review/community access | Buyer language, objections, switching behaviour | Keep buyer language SIMULATED, not researched |
| AI platform access | Live visibility testing | Keep prompts as a test plan marked NOT TESTED |
| First-party analytics (e.g. search performance data for the brand's own site) | Actual brand search performance | Do not infer actual performance from third-party data |

### Discovery procedure

1. Inspect the tools actually present in this session: connected MCP servers and connectors, search and fetch tools, browser access, and any deferred tools that can be loaded by searching for them. Map each to the capabilities above. A single provider often covers several capabilities, and several providers can cover one.
2. Confirm a capability works by using it, not by seeing that a connector exists. A connector can be installed but unauthenticated or out of credits. Treat a capability as available only after a real call succeeds.
3. Treat files the user supplies (keyword exports, Search Console exports, rank tracker or review dumps) as a valid source for a capability. Record them as SUPPLIED with the date the data was collected, which is often different from the file's save date or today's report date. Ask for the collection date if the file does not show one, and mark it UNKNOWN if the user cannot say.
4. Prefer a provider the user already has connected. Do not ask the user to adopt a new tool when an existing one covers the capability, and do not assume any provider exists.
5. Before research starts, tell the user briefly which capabilities are available, which providers will fulfil them, and which will be skipped. Then proceed with what is available and skip the rest gracefully, applying the "If unavailable" column above. Do not stall waiting for a missing tool.

### Recording provider evidence

For every metric or finding drawn from a tool, record the provider, the metric definition as that provider defines it, the geography and language settings, and the data collection date. A capability that was skipped is reported as unavailable or NOT TESTED in the methodology section, never silently dropped.

### Capability confidence

Access comes in different strengths, and a reader should not treat them as equivalent. Label each capability used with one of:

- **Live**: a real call succeeded during this task, so the data reflects the report date.
- **Supplied historical**: the data came from a user-provided export or document and reflects its collection date, not today.
- **Partial**: the capability worked only in part, for example a keyword tool that returned volume but no difficulty, a plan limited to some countries, truncated results, or a rate-limited run.

Show these labels in the capability disclosure before research starts and again in the methodology section. Findings built on Supplied historical or Partial data carry that status with them, so a conclusion is never stated more firmly than its weakest input.

### Data freshness

Report two dates separately: when the data was collected and when this report was generated. Flag any supplied data whose collection date is old enough that the market may have moved. As a rule of thumb, treat keyword and SERP exports older than about 90 days, and AI-assistant outputs older than about 30 days, as potentially stale, and say so next to the finding. The user can adjust these thresholds. Stale data can still be used when nothing fresher exists, but label it as historical and do not present it as the current state.

### Source conflicts

When two providers (or a provider and a supplied export) disagree on the same metric, keep both values and report them side by side with their provider, date and settings. Do not average them, pick a winner silently, or blend them into one score. Briefly explain plausible causes, such as different keyword databases or update cycles, different geography or language settings, different volume definitions (rounded, averaged, or clickstream-adjusted), different collection dates, or different SERP location and device. If the cause cannot be established, say it is unexplained. Where a decision depends on the disputed figure, show how the recommendation changes under each value, or flag it as needing a tie-break from first-party data.

## Workflow

### 1. Research the brand and market

When web access is available, inspect the official website and relevant pages:
- Homepage and about page
- Product/service category pages and key individual offerings
- Pricing, FAQs, delivery, stockists, locations, and support pages
- Educational resources, case studies, or comparison pages

Use relevant credible external sources where helpful: competitors, independent reviews, industry sources, customer discussions, and search results.

Build a concise brand fact sheet:
- Brand positioning and value proposition
- Products/services and subcategories
- Differentiators (labelled by evidence type)
- Audiences and use cases
- Customer problems addressed
- Likely purchase criteria and objections
- Pricing model and buying channels, where verifiable
- Target-market terminology and location relevance
- Product claims that need careful wording

Cite researched factual claims next to the claim they support, and label each with the evidence classification: **SUPPLIED** (from the user or brand), **OBSERVED** (found directly in a source reviewed during this task), **VALIDATED** (supported by research evidence or quantitative data), **INFERRED** (a reasonable interpretation), or **UNKNOWN** (not verified or not accessible). A URL alone does not validate a claim; inspect the source content, and prefer multiple independent sources for important commercial claims.

Do not invent products, certifications, retailers, service areas, prices, or claims. Do not treat brand marketing claims as independent evidence.

### 2. Build buyer personas and jobs-to-be-done

Create 3–6 useful personas for Standard depth, scaling to the brand's complexity. Avoid generic personas that could fit any company.

For each persona capture:
- Situation and trigger
- Desired outcome
- Main problem or job-to-be-done
- Requirements and constraints
- Budget sensitivity
- Main objections and perceived risks
- Research habits and likely channels
- Relevant location or buying context

Include the people who influence or approve purchases when the business is B2B. For consumer businesses, use realistic life-stage, use-case, or need-based segments. Label inferred personas as simulated, not actual customers.

### 3. Map the buyer journey

Use and adapt these stages:
1. **Problem awareness:** the buyer recognizes a need.
2. **Category discovery:** the buyer explores solution types.
3. **Evaluation:** the buyer compares features, ingredients, specifications, approaches, or suitability.
4. **Brand evaluation:** the buyer researches specific brands, reviews, proof, alternatives, and trade-offs.
5. **Purchase readiness:** the buyer looks for price, stock, availability, booking, delivery, or a seller.
6. **Post-purchase / switching:** the buyer seeks setup, usage, troubleshooting, replacement, or alternatives, when relevant.

Do not force every business into an identical funnel. Map the stages to the actual buying process.

### 4. Generate the Google-style search library

Generate natural, plausible queries grouped by the categories that fit the brand. Potential categories include:
- Broad category discovery
- Product/service discovery
- Specific attributes, ingredients, features, or specifications
- Problem-led and use-case searches
- Audience, life-stage, or experience-level searches
- Informational and educational questions
- Price, cost, value, and affordability
- Reviews and reputation
- Brand comparisons and alternatives
- Branded navigational and product queries
- Transactional and purchase-ready searches
- Local, nearby, and stockist searches
- Delivery, availability, and service-area searches
- Switching, troubleshooting, or post-purchase searches
- Seasonal queries, only when relevant

Use local spelling, terminology, currency, and geography. Do not append the country name mechanically to every query. Include head terms, mid-tail, long-tail, questions, comparison phrases, and location modifiers where realistic.

Avoid duplicates and meaningless rewrites. Preserve variations that represent a genuinely different intent, persona, product requirement, or location.

For each query, record:
- `query_id`
- `query`
- `primary_intent` (Informational, Commercial investigation, Transactional, Navigational, or Local)
- `journey_stage`
- `persona`
- `product_or_service_category`
- `brand_relationship` (Non-branded, Target-brand, Competitor-related)
- `hypothesis_rationale`
- `evidence_status` (SIMULATED until validated; then OBSERVED, e.g. autocomplete or PAA, or VALIDATED with a metric source; use the classification in `references/research-validation.md`)
- `evidence_ids`, linking to ledger entries in Research and Full Intelligence Modes
- `source_or_notes`, when applicable

Do not call queries “high volume,” “popular,” “easy to rank,” or “low competition” without supporting data. A generated query is a hypothesis, not validated demand.

### 5. Generate conversational AI prompt library

Create realistic prompts a buyer could submit to ChatGPT, Perplexity, Gemini, Copilot, or similar assistants. Do not make every prompt mention the target brand.

Cover applicable prompt types:
- General recommendations
- Context-rich recommendations with needs and constraints
- Problem-solving
- Product/service comparison
- Feature, ingredient, specification, or evidence checks
- Target-brand evaluation
- Competitor comparison
- Price and total-cost analysis
- Trust, reviews, credentials, and claims
- Local recommendations and availability
- Purchase planning
- Switching and objections
- Follow-up questions that depend on a prior answer

Prompts should sound like real people, not keyword strings dressed up as dialogue. Vary length and context. Include budget, location, use case, current solution, requirements, and trade-offs where plausible.

For each prompt, record:
- `prompt_id`
- `initial_prompt`
- `primary_intent`
- `journey_stage`
- `persona`
- `product_or_service_category`
- `brand_relationship` (Non-branded discovery, Target-brand evaluation, Competitor comparison, Purchase-ready)
- `suggested_follow_up`
- `what_the_test_measures`
- `evidence_status` (SIMULATED unless actually tested; NOT TESTED until a live run is recorded)

### 6. Create simulated multi-turn conversations

Provide the number appropriate to the selected depth. Each conversation must have a distinct buying situation and include:
1. Persona and context
2. Initial prompt
3. Follow-up based on a plausible answer
4. A narrowing or comparison question
5. A purchase-oriented or decision question
6. What the sequence is designed to test

These are synthetic scenarios, not actual customer transcripts. Do not fabricate assistant answers or present hypothetical conversations as real user research. If useful, provide the buyer prompts only, ready to paste into a target platform.

### 7. Generate local and regional queries

When geography matters, use the requested country and named locations. Include realistic patterns such as:
- category + “near me”
- brand + city
- retailer/provider + location
- product/service + city or region
- stockist or availability questions
- delivery/service coverage

If no cities are specified, select a representative set of relevant places for the target country and explain the selection briefly. Do not imply the brand operates in a location or a shop stocks a product unless verified. For online-only businesses, focus on delivery coverage, shipping, and availability instead of pretending local stores matter.

### 8. Prioritize a test set

Select a balanced shortlist appropriate to the requested depth. Include:
- Non-branded discovery
- Product- or use-case-specific searches
- Informational questions
- Comparison and brand-evaluation queries
- Transactional searches
- Local queries when relevant

Prioritize qualitatively using:
1. Relevance to verified offerings
2. Likely buyer intent
3. Fit with the target audience
4. Commercial importance
5. Strategic value across the journey
6. Ability to address the need with existing or feasible content

If actual keyword volume, difficulty, rankings, conversions, or customer data is available, incorporate it and cite the data source. Otherwise label the prioritization **qualitative hypothesis**. Do not invent numeric scores that imply measured precision. If using a scoring model, define its rubric and identify all scores as estimates.

### 9. Separate query discovery, demand validation, and visibility testing

These are separate workstreams and must be reported separately.

#### A. Query discovery
Output: a plausible, deduplicated library of buyer questions. This establishes what is worth testing, not whether people actually search it.

#### B. Demand validation
Where tools/data are available, validate candidate queries using Google autocomplete/PAA/search results, Google Trends, Search Console, a keyword research platform, or other credible sources. Record:
- Tool/source and date
- Market and language settings
- Search volume and units, if supplied
- Trend/seasonality, if supplied
- Competition/difficulty metric and its provider, if supplied
- Validation limitations

Do not fabricate values. Do not treat autocomplete or a search result as proof of search volume. If no demand data is available, mark demand as **unvalidated**.

For each priority keyword or query cluster capture monthly search volume, keyword difficulty, CPC, intent, trend direction, geographic scope, source and date, at each provider's original granularity. Never blend metrics from different providers into one score without explaining the method. When exact volume is unavailable, use labelled qualitative demand indicators. Generated queries stay hypotheses until validated.

#### C. Visibility testing
Run selected prompts against actual platforms only when tools or user-provided outputs permit it. Record each observation with:
- Test ID
- Exact query/prompt
- Platform and product/mode, where known
- Test date and market/language context
- Fresh or continuing conversation
- Whether the brand is mentioned
- Whether it is recommended or merely mentioned
- Relevant products/services named
- Competitors named
- Sources/citations returned
- Whether the official site is cited
- Accuracy and relevance notes
- Raw response or a faithful excerpt, subject to practical length limits

Use **Not tested** when no direct test was performed. Never infer actual AI visibility from a generated prompt list.

For important prompts, repeat tests across fresh conversations and dates where practical. AI answers vary. Report observed results as snapshots, not guarantees of persistent ranking.

### 10. Analyze observed visibility only when evidence exists

If real test results are available, analyze:
- Brand mention rate
- Recommendation rate
- Official-site citation rate
- Product/service coverage
- Competitor co-mentions
- Accuracy and outdated claims
- Source patterns
- Journey stages where the brand is absent
- Opportunities to improve relevant pages or third-party evidence

Do not infer AI visibility from keyword rankings, web search results or generated conversations. Define denominators and sample sizes. For example, mention rate = prompts with a brand mention / prompts tested. Do not mix untested prompts into the denominator. Separate mention, recommendation, and citation metrics.

If no visibility tests were run, provide a measurement plan rather than pretending to have results.

### 11. Validate buyer language and competitors (Research and Full Intelligence Modes)

Use reviews, forums, Reddit, Q&A platforms and competitor pages to ground the simulation in real evidence. Investigate buying triggers, objections, frustrations, comparison criteria, switching behaviour, trust signals, abandonment reasons, and the language buyers actually use, separating recurring patterns from single anecdotes. For each relevant competitor, classify it as direct, indirect, alternative or adjacent and review positioning, pricing, specifications, differentiators, content coverage, search visibility, review complaints and gaps, from the pages themselves rather than snippets. Simulated buyer responses must never be presented as customer research. Record findings in the evidence ledger (format in `references/research-validation.md`).

### 12. Produce actionable recommendations

Connect recommendations directly to query clusters and evidence. Consider:
- Existing pages that may satisfy the intent
- Content gaps
- Category and product page improvements
- FAQs and explanatory resources
- Comparison content
- Trust and evidence gaps
- Local/stockist information
- Internal linking
- Schema or structured data only when appropriate
- Third-party sources that may influence discovery
- High-priority prompts for recurring monitoring

Every major content recommendation must cite the query IDs, AI prompt IDs, persona, journey stage and supporting evidence IDs behind it, plus any established competitor gap, the proof or information required, the recommended format, and the priority with its rationale. Do not recommend content just because a keyword exists; explain the buyer need it serves. See `references/research-validation.md` section 9.

Do not promise that a particular content change will make an AI system cite the brand. Describe recommendations as opportunities to improve clarity, usefulness, crawlability, evidence, or discoverability.

## Required report structure

All modes:

1. **Executive summary** — market, brand, scope, mode, key findings or hypotheses.
2. **Research method and limitations** — mode, tools discovered and used, tools unavailable, sources reviewed, dates, and what was not tested.
3. **Brand fact sheet** — SUPPLIED, OBSERVED, INFERRED and UNKNOWN facts.
4. **Buyer personas and jobs-to-be-done**.
5. **Google-style query library** — categorized tables with metadata.
6. **AI prompt library** — categorized prompts and follow-ups.
7. **Simulated multi-turn conversations**.
8. **Local/regional queries**, where relevant.
9. **Priority test set** — query, channel, stage, intent, rationale, validation status.
10. **Demand validation** — only if data was actually gathered; otherwise explicitly say unvalidated.
11. **Visibility testing results** — only if actual tests were performed; otherwise provide a ready-to-run test plan marked NOT TESTED.
12. **Recommendations** — prioritized and tied to query clusters.
13. **Appendix / export-ready data** — consistent IDs and spreadsheet-ready tables or CSV-ready output if requested.

Research and Full Intelligence reports must additionally include (place them alongside the sections above; do not drop any of the 13): research methodology and tools used; research coverage and limitations; keyword demand findings; competitor intelligence; buyer language and observed objections; evidence-backed content opportunities; the evidence ledger; AI visibility results if actually tested; and unvalidated hypotheses and outstanding questions.

Simulation reports keep the structure above, with every generated insight identified as SIMULATED or unvalidated.

If both a Markdown report and an Excel workbook are delivered, use identical IDs and findings in both.

## Quality assurance checklist

Before delivery, verify:
- The correct brand, URL, country, and language were used.
- Website inspection is claimed only if performed.
- Product and competitor facts are sourced or labeled unknown.
- Queries reflect real buyer situations and the brand's actual offerings.
- Both branded and non-branded discovery are represented.
- Queries cover multiple buyer journey stages.
- Google-style queries and AI prompts are meaningfully different formats.
- AI follow-ups logically build on previous turns.
- Local queries do not invent service coverage or stockists.
- Duplicate and low-value variants are removed.
- Priority claims are evidence-based or clearly qualitative.
- Search demand and brand visibility are not inferred from query generation.
- Any metrics have sources, dates, definitions, and denominators.
- Recommendations trace back to queries or observed evidence.
- Simulated content is not presented as actual customer research.
- Any incomplete research or tool limitations are stated plainly.
- Every quantitative metric has a source and collection date, and unavailable metrics are marked unavailable rather than invented.
- Every important external finding has a supporting source that was actually inspected.
- Competitor claims rest on inspected evidence, and competitors are classified direct, indirect, alternative or adjacent.
- No SIMULATED or INFERRED finding has been promoted to VALIDATED.
- Every content recommendation links to a buyer need, query/prompt IDs and evidence IDs.
- IDs and findings match across the Markdown report and any Excel workbook.

## Startup message

Always ask the user to select a research mode before collecting brand details or starting any research. Brand details are requested only after the mode is chosen. Open with:

“# Buyer AI Search Simulator

Let's investigate how buyers discover, compare and choose brands across Google and AI search.

First, choose your research mode:

1. **Simulation Mode**
   Generate buyer personas, search queries, AI prompts and simulated buyer journeys. No external research required. All findings are labelled as hypotheses or simulated insights.

2. **Research Mode**
   Conduct market research using available web search and keyword research tools. Validate search demand, investigate competitors, analyse SERPs and explore actual buyer discussions.

3. **Full Intelligence Mode**
   Combine market research, simulated buyer journeys and live AI visibility testing across accessible AI platforms. Track brand mentions, competitor recommendations, citations and factual accuracy.

The research capabilities available depend on your connected tools. I will identify available capabilities before starting and clearly disclose anything that cannot be tested or validated.”

Wait for the user's choice. Then ask for the brand details:

“## Brand information

Please provide:

1. **Brand name**
2. **Official website URL**
3. **Target country or market**

Optional:
- Target cities or regions
- Product or service categories
- Known competitors
- Target audience
- Research objective
- Research depth: Quick, Standard or Comprehensive
- Intended use: SEO, GEO, content strategy or all three

I'll use your selected mode to determine the research workflow and deliverables.”

Handling shortcuts:
- If the user's opening message already names a mode (for example "run Research Mode for brand X"), skip the mode question and confirm it in one line.
- If the user supplied the required brand inputs but no mode, do not re-ask for the inputs; ask only the mode question, then proceed.
- If the user names both mode and inputs, start the workflow immediately, beginning with tool discovery for Research and Full Intelligence Modes.