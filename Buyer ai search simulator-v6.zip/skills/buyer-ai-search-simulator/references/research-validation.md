# Research Validation Reference

Read this file when running **Research Mode** or **Full Intelligence Mode**. It holds the detailed rules for evidence handling, tool discovery, demand validation, buyer and competitor research, AI visibility testing, and content-opportunity mapping. SKILL.md holds the workflow; this file holds the standards that keep validated findings separate from generated hypotheses.

## Contents
1. Operating mode details
2. Research tool discovery and availability
3. Evidence classification
4. Source-backed evidence ledger
5. Keyword demand validation
6. Buyer research validation
7. Competitor intelligence
8. AI visibility testing
9. Content opportunity evidence mapping
10. Additional report sections
11. Additional quality assurance checks

---

## 1. Operating mode details

### Simulation Mode
Use when external research tools are unavailable or the user explicitly requests a simulated report.

- Generate buyer personas, jobs-to-be-done, search queries and AI prompts.
- Simulate buyer journeys and multi-turn conversations.
- Generate hypotheses about search intent, objections, buying triggers and content opportunities.
- Do not claim search demand, competitor findings, rankings, citations or AI visibility.
- Label generated insights as hypotheses or simulated findings.

### Research Mode
Use available web search and keyword research tools to validate the generated research.

Research may include:
- Search demand and keyword metrics.
- Search engine results pages (SERPs).
- Autocomplete, related searches and People Also Ask.
- Competitor websites, product pages and content.
- Customer reviews, forums, Reddit and public Q&A discussions.
- Google Trends and seasonality.
- Local and regional search intent.
- Content gaps and competitor positioning.

For keyword research, use available tools such as Ahrefs, Semrush, Google Keyword Planner or equivalent. Record the tool used, metric, geography, date and relevant limitations. Retrieve keyword metrics using any connected keyword research provider or user-supplied export. Record the provider, metric, geography, date and limitations.

Never invent unavailable metrics. If a tool cannot provide a requested metric, mark it as unavailable.

### Full Intelligence Mode
Combine Research Mode with:
- Buyer persona and journey simulation.
- Multi-turn conversational testing.
- Actual AI assistant visibility testing, where accessible.
- Brand and competitor mention tracking.
- Citation and source analysis.
- Recommendation and factual accuracy analysis.
- Actionable SEO and GEO recommendations.

Do not treat simulated AI conversations as actual AI platform visibility tests. If live AI platform testing is unavailable, retain the test prompts as a testing plan and clearly mark results as NOT TESTED.

---

## 2. Research tool discovery and availability

Before starting Research or Full Intelligence Mode:

1. Identify which research tools are available.
2. Identify which tools can provide keyword metrics.
3. Identify whether search results, page content, reviews and forums can be accessed.
4. Identify whether actual AI assistant testing is possible.
5. Record unavailable capabilities.

Use available tools rather than assuming a particular provider or API exists. Do not claim to have used a tool unless it was actually used.

Fallback rules:
- Only web search available: conduct qualitative research and label quantitative search metrics as unavailable.
- Only keyword research tools available: validate demand, but do not claim to have performed competitor or buyer discussion research.
- Neither available: fall back to Simulation Mode.

Record the outcome of this check in the report's "Research methodology and tools used" section (what was available, what was used, what was unavailable).

---

## 3. Evidence classification

Every meaningful finding must carry exactly one of these labels:

| Label | Meaning |
|---|---|
| SUPPLIED | Information explicitly provided by the user or brand. |
| OBSERVED | Information directly found in a source, search result, product page, review or discussion. |
| VALIDATED | A finding supported by relevant research evidence or quantitative data. |
| INFERRED | A reasonable interpretation of supplied or observed information. |
| SIMULATED | A generated persona, query, prompt, conversation or hypothetical buyer response. |
| UNKNOWN | Information that cannot currently be established. |
| NOT TESTED | A research or visibility test that was planned but not executed. |

Never promote a simulated or inferred finding into a validated finding. Promotion requires new evidence from a real source or tool, and the label changes only when that evidence is recorded in the ledger.

---

## 4. Source-backed evidence ledger

Maintain an evidence ledger for Research and Full Intelligence Modes.

| Field | Description |
|---|---|
| Evidence ID | Unique reference |
| Finding | The specific claim or observation |
| Evidence type | Supplied, observed, validated, inferred, simulated, unknown |
| Source name | Website, tool, platform or publication |
| Source URL | Direct URL where available |
| Research date | Date the evidence was collected |
| Geography | Country, market or region |
| Metric | Search volume, CPC, keyword difficulty, etc. |
| Metric value | Exact value returned by the source |
| Confidence | High, medium or low |
| Limitations | Sampling, missing data or methodological caveats |
| Related IDs | Associated query, prompt or recommendation IDs |

Rules:
- Cite sources next to the claims they support in the report.
- A source URL alone does not validate a claim. Inspect the relevant source content.
- Use multiple independent sources where appropriate, especially for important commercial or competitive claims.
- Do not treat search snippets as equivalent to reviewing the underlying page.

---

## 5. Keyword demand validation

For each priority keyword or query cluster, capture the available metrics:

- Monthly search volume.
- Keyword difficulty.
- CPC.
- Search intent.
- Trend direction.
- Geographic scope.
- Source and research date.

Rules:
- Keep metrics at their original granularity.
- Do not combine metrics from different providers into a single apparently comparable score without explaining the methodology.
- Where exact search volume is unavailable, use qualitative demand indicators and label them accordingly.
- Generated queries remain hypotheses until validated.

---

## 6. Buyer research validation

Use publicly accessible reviews, forums, Reddit discussions, Q&A platforms and other relevant sources to investigate:

- Buying triggers.
- Purchase objections.
- Common frustrations.
- Product comparison criteria.
- Switching behaviour.
- Trust signals.
- Reasons for abandoning purchases.
- Language buyers actually use.

Rules:
- Distinguish recurring patterns (seen across several independent sources) from individual anecdotes.
- Do not present simulated buyer responses as customer interviews or actual customer feedback.

---

## 7. Competitor intelligence

For each relevant competitor, investigate where possible:

- Product and service positioning.
- Pricing and packaging.
- Product specifications.
- Differentiators and proof points.
- Content coverage.
- Search visibility.
- Reviews and recurring customer complaints.
- Gaps that may represent opportunities.

Rules:
- Do not assume every brand in a supplied competitor list is a direct competitor.
- Classify each competitor as **direct**, **indirect**, **alternative** or **adjacent**.
- Competitor claims must rest on inspected evidence (the page or source itself), not on snippets or assumption.

---

## 8. AI visibility testing

For Full Intelligence Mode, test priority prompts against accessible AI assistants.

Record for each test:
- Platform and model, where known.
- Date and time.
- Exact prompt.
- Conversation context.
- Brand mention.
- Competitor mentions.
- Recommendation position.
- Cited sources.
- Factual accuracy.
- Missing or misleading information.

Rules:
- Use fresh sessions where possible.
- Do not infer AI visibility from keyword rankings, web search results or generated conversations.
- If testing is not performed, report the test set as a proposed testing protocol (status NOT TESTED), not a visibility result.

---

## 9. Content opportunity evidence mapping

Every major content recommendation should reference:

- Relevant query IDs.
- Relevant AI prompt IDs.
- Related buyer persona.
- Buyer journey stage.
- Supporting evidence IDs.
- Competitor gap, where established.
- Required proof or information.
- Recommended content format.
- Priority and rationale.

Do not recommend content simply because a keyword exists. Explain the buyer need it addresses. If a recommendation rests only on simulated or inferred material, say so and label it a hypothesis to test.

---

## 10. Additional report sections

Research and Full Intelligence reports must include:

1. Research methodology and tools used.
2. Research coverage and limitations.
3. Keyword demand findings.
4. Competitor intelligence.
5. Buyer language and observed objections.
6. Evidence-backed content opportunities.
7. Evidence ledger.
8. AI visibility results, if actually tested.
9. Unvalidated hypotheses and outstanding questions.

Simulation reports keep the original structure but clearly identify all generated insights as simulated or unvalidated.

---

## 11. Additional quality assurance checks

Before completing the report, verify:

- Every quantitative metric has a source and collection date.
- Every important external finding has a supporting source.
- Search demand is not confused with AI visibility.
- Simulated conversations are not represented as real customer research.
- Competitor claims are supported by inspected evidence.
- Missing metrics are marked unavailable rather than invented.
- Every content recommendation links back to buyer needs and relevant evidence.
- Research limitations are disclosed.
- The Excel workbook (if delivered) and the Markdown report use consistent IDs and findings.
